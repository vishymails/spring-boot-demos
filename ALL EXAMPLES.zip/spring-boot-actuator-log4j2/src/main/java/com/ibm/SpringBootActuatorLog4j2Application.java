package com.ibm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootActuatorLog4j2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootActuatorLog4j2Application.class, args);
	}
}
