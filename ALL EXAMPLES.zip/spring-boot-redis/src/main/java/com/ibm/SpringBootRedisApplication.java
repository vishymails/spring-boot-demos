package com.ibm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

@SpringBootApplication
public class SpringBootRedisApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRedisApplication.class, args);
	}

	@Autowired
	private StringRedisTemplate template;
	
	@Override
	public void run(String... arg0) throws Exception {
		// TODO Auto-generated method stub
		
		ValueOperations<String, String> ops = this.template.opsForValue();
		
		String key = "spring.boot.vodafone.demo";
		
		if(!this.template.hasKey(key))
		{
			ops.set(key,  "DEMO REDIS");
		}
		
		System.out.println("Found Key" + key + ", value = " + ops.get(key));
		
	}
}
