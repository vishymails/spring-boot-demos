insert into FLIGHT
(id, origin, destination, airline, flight_number, traveler)
values
(1, 'Nashville', 'Dallas', 'Spring Ways', 'OAUTH2', 'Greg Turnquist');
